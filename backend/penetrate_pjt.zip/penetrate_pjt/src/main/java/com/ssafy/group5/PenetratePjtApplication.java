package com.ssafy.group5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenetratePjtApplication {

	public static void main(String[] args) {
		SpringApplication.run(PenetratePjtApplication.class, args);
	}

}
