package com.ssafy.group5.dto;

import lombok.Data;

@Data
public class Myplace {
	private String userId;
	private int attractionId;
}
