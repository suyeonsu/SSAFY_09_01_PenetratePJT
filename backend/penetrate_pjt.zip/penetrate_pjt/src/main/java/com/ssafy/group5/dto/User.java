package com.ssafy.group5.dto;

import lombok.Data;

@Data
public class User {
    private String userid;
    private String userpwd;
    private String username;
    private String email;
    private String joindate;
}